﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace AirLineProgram
{
    public partial class FligthTbl : Form
    {
        public FligthTbl()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-79HMS7E;Initial Catalog=AirLine;Integrated Security=True");


        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void btnRecord_Click(object sender, EventArgs e)
        {
            Verificar();
            try
            {
                Con.Open();
                string Query = "insert into FlightTbl values('" + txtFlightCode.Text + "','" + cmbSource.SelectedItem.ToString()
                    + "','" + cmbDestination.SelectedItem.ToString() + "','" + dtTakeOfDate.Value.ToString()
                    + "','" + txtNumOfSeat.Text+"')";
                SqlCommand cmd = new SqlCommand(Query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Flight Recorded Successfully");
                Con.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }
        public void Verificar()
        {
            if (txtFlightCode.Text == "" || cmbSource.Text == "" || cmbDestination.Text == ""
                || dtTakeOfDate.Text == "" || txtNumOfSeat.Text == "")
            {
                MessageBox.Show("Error");
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtFlightCode.Text = "";
            txtNumOfSeat.Text = "";
            cmbDestination.SelectedItem = "";
            cmbSource.SelectedItem = "";
        }

        private void FligthTbl_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            ViewFligths viewpass = new ViewFligths();
            viewpass.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
