﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AirLineProgram
{
    public partial class AddPassenger : Form
    {
        public AddPassenger()
        {
            InitializeComponent();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-79HMS7E;Initial Catalog=AirLine;Integrated Security=True");

        private void AddPassenger_Load(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnRecord_Click(object sender, EventArgs e)
        {
            Verificar();
            try
            {
                Con.Open();
                string Query = "insert into PassengerTbl values("+txtPassengerId.Text+ ",'" + txtPassName.Text 
                    +"','" +txtPassNumber.Text+"','"+txtPassAdress.Text+"','"+ cmbNationality.SelectedItem.ToString() + "','"
                    +cmbGender.SelectedItem.ToString()+ "','" +txtPhone.Text +"')";
                SqlCommand cmd = new SqlCommand(Query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Passeger Recorded Successfully");
                Con.Close();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        public void Verificar()
        {
            if (txtPassengerId.Text == "" || txtPassAdress.Text == "" || txtPassName.Text == "" 
                || txtPassNumber.Text == "" || txtPhone.Text == "")
            {
                MessageBox.Show("Complete todos los campos");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ViewPassengers viewpass = new ViewPassengers();
            viewpass.Show();
            this.Hide();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtPassengerId.Text = "";
            txtPassName.Text = "";
            txtPassAdress.Text = "";
            txtPassNumber.Text = "";
            txtPhone.Text = "";
            cmbGender.SelectedItem = "";
            cmbGender.SelectedItem = "";
        }
    }
}
