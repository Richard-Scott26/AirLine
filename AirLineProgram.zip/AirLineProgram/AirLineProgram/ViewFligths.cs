﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AirLineProgram
{
    public partial class ViewFligths : Form
    {
        public ViewFligths()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=DESKTOP-79HMS7E;Initial Catalog=AirLine;Integrated Security=True");
        private void Populate()
        {
            Con.Open();
            string Query = "select * from FlightTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, Con);
            SqlCommandBuilder build = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            dgvViewFlights.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtFlightCode.Text == "")
            {
                MessageBox.Show("Enter the Flight to delete");
            }
            else
            {
                try
                {
                    Con.Open();
                    string Query = "delete from FlightTbl where Fcode='" + txtFlightCode.Text+"';";
                    SqlCommand cmd = new SqlCommand(Query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Passenger Deleted Successfully");
                    Con.Close();
                    Populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void dgvViewFlights_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                txtFlightCode.Text = dgvViewFlights.SelectedRows[0].Cells[0].Value.ToString();
                cmbSource.SelectedItem = dgvViewFlights.SelectedRows[0].Cells[1].Value.ToString();
                cmbDestination.SelectedItem = dgvViewFlights.SelectedRows[0].Cells[2].Value.ToString();
                txtNumOfSeat.Text = dgvViewFlights.SelectedRows[0].Cells[3].Value.ToString();
            }
            catch (Exception Ex)
            {
                MessageBox.Show("Error");
            }
        }

        private void ViewFligths_Load(object sender, EventArgs e)
        {
            Populate();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            FligthTbl addpas = new FligthTbl();
            addpas.Show();
            this.Hide();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtFlightCode.Text = "";
            txtNumOfSeat.Text = "";
            cmbDestination.SelectedItem = "";
            cmbSource.SelectedItem = "";
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtFlightCode.Text == "" || txtNumOfSeat.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "update FlightTbl set Fsrc='" + cmbSource.SelectedItem.ToString()
                        + "',FDest='" + cmbDestination.SelectedItem.ToString() + "',FDate='" + dtViewFlight.Value.Date.ToString()
                        + "',FCap='" + txtNumOfSeat.Text+"' where Fcode='" + txtFlightCode.Text + "';";

                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Flight Updated Successfully");
                    Con.Close();
                    Populate();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
    }
}
